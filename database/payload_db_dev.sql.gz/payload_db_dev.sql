-- -------------------------------------------------------------
-- TablePlus 6.0.0(550)
--
-- https://tableplus.com/
--
-- Database: payload_db_dev
-- Generation Time: 2024-05-03 17:51:08.7140
-- -------------------------------------------------------------


DROP TABLE IF EXISTS "public"."categories";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS categories_id_seq;

-- Table Definition
CREATE TABLE "public"."categories" (
    "id" int4 NOT NULL DEFAULT nextval('categories_id_seq'::regclass),
    "title" varchar,
    "updated_at" timestamptz(3) NOT NULL DEFAULT now(),
    "created_at" timestamptz(3) NOT NULL DEFAULT now(),
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."media";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS media_id_seq;

-- Table Definition
CREATE TABLE "public"."media" (
    "id" int4 NOT NULL DEFAULT nextval('media_id_seq'::regclass),
    "alt" varchar,
    "updated_at" timestamptz(3) NOT NULL DEFAULT now(),
    "created_at" timestamptz(3) NOT NULL DEFAULT now(),
    "url" varchar,
    "thumbnail_u_r_l" varchar,
    "filename" varchar,
    "mime_type" varchar,
    "filesize" numeric,
    "width" numeric,
    "height" numeric,
    "caption" jsonb,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."newsletter";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS newsletter_id_seq;

-- Table Definition
CREATE TABLE "public"."newsletter" (
    "id" int4 NOT NULL DEFAULT nextval('newsletter_id_seq'::regclass),
    "subject" varchar NOT NULL,
    "updated_at" timestamptz(3) NOT NULL DEFAULT now(),
    "created_at" timestamptz(3) NOT NULL DEFAULT now(),
    "title" varchar NOT NULL,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."newsletter_blocks_quote";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Table Definition
CREATE TABLE "public"."newsletter_blocks_quote" (
    "_order" int4 NOT NULL,
    "_parent_id" int4 NOT NULL,
    "_path" text NOT NULL,
    "id" varchar NOT NULL,
    "quote_header" varchar NOT NULL,
    "quote_text" varchar,
    "block_name" varchar,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."pages";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS pages_id_seq;

-- Table Definition
CREATE TABLE "public"."pages" (
    "id" int4 NOT NULL DEFAULT nextval('pages_id_seq'::regclass),
    "title" varchar,
    "updated_at" timestamptz(3) NOT NULL DEFAULT now(),
    "created_at" timestamptz(3) NOT NULL DEFAULT now(),
    "meta_title" varchar,
    "meta_description" varchar,
    "slug" varchar NOT NULL,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."pages_blocks_quote";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Table Definition
CREATE TABLE "public"."pages_blocks_quote" (
    "_order" int4 NOT NULL,
    "_parent_id" int4 NOT NULL,
    "_path" text NOT NULL,
    "id" varchar NOT NULL,
    "quote_header" varchar NOT NULL,
    "quote_text" varchar,
    "block_name" varchar,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."payload_migrations";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS payload_migrations_id_seq;

-- Table Definition
CREATE TABLE "public"."payload_migrations" (
    "id" int4 NOT NULL DEFAULT nextval('payload_migrations_id_seq'::regclass),
    "name" varchar,
    "batch" numeric,
    "updated_at" timestamptz(3) NOT NULL DEFAULT now(),
    "created_at" timestamptz(3) NOT NULL DEFAULT now(),
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."payload_preferences";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS payload_preferences_id_seq;

-- Table Definition
CREATE TABLE "public"."payload_preferences" (
    "id" int4 NOT NULL DEFAULT nextval('payload_preferences_id_seq'::regclass),
    "key" varchar,
    "value" jsonb,
    "updated_at" timestamptz(3) NOT NULL DEFAULT now(),
    "created_at" timestamptz(3) NOT NULL DEFAULT now(),
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."payload_preferences_rels";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS payload_preferences_rels_id_seq;

-- Table Definition
CREATE TABLE "public"."payload_preferences_rels" (
    "id" int4 NOT NULL DEFAULT nextval('payload_preferences_rels_id_seq'::regclass),
    "order" int4,
    "parent_id" int4 NOT NULL,
    "path" varchar NOT NULL,
    "users_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."users";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS users_id_seq;

-- Table Definition
CREATE TABLE "public"."users" (
    "id" int4 NOT NULL DEFAULT nextval('users_id_seq'::regclass),
    "name" varchar,
    "updated_at" timestamptz(3) NOT NULL DEFAULT now(),
    "created_at" timestamptz(3) NOT NULL DEFAULT now(),
    "email" varchar NOT NULL,
    "reset_password_token" varchar,
    "reset_password_expiration" timestamptz(3),
    "salt" varchar,
    "hash" varchar,
    "login_attempts" numeric,
    "lock_until" timestamptz(3),
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."users_roles";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS users_roles_id_seq;
DROP TYPE IF EXISTS "public"."enum_users_roles";
CREATE TYPE "public"."enum_users_roles" AS ENUM ('admin', 'user');

-- Table Definition
CREATE TABLE "public"."users_roles" (
    "order" int4 NOT NULL,
    "parent_id" int4 NOT NULL,
    "value" "public"."enum_users_roles",
    "id" int4 NOT NULL DEFAULT nextval('users_roles_id_seq'::regclass),
    PRIMARY KEY ("id")
);

INSERT INTO "public"."newsletter" ("id", "subject", "updated_at", "created_at", "title") VALUES
(4, 'My Newsletter Subject', '2024-04-28 15:37:41.427+00', '2024-04-28 13:12:01.834+00', 'My Newsletter 1');

INSERT INTO "public"."newsletter_blocks_quote" ("_order", "_parent_id", "_path", "id", "quote_header", "quote_text", "block_name") VALUES
(1, 4, 'layout', '662e559bc9fb864bfac4ebdd', 'Wir sind zu schlecht für Sicherheitsschläge.', 'Ein weiser Mann', NULL),
(2, 4, 'layout', '662e55b4c9fb864bfac4ebde', 'Ehre den Hang!', 'Ein anderer weiser Mann', NULL);

INSERT INTO "public"."pages" ("id", "title", "updated_at", "created_at", "meta_title", "meta_description", "slug") VALUES
(1, 'My Page Title', '2024-04-28 14:06:52.405+00', '2024-04-28 14:06:52.405+00', 'My Page Meta Title', 'My Page Meta Description', 'my-page');

INSERT INTO "public"."payload_migrations" ("id", "name", "batch", "updated_at", "created_at") VALUES
(1, 'dev', -1, '2024-05-03 15:49:46.368+00', '2024-04-20 15:37:42.441+00');

INSERT INTO "public"."payload_preferences" ("id", "key", "value", "updated_at", "created_at") VALUES
(1, 'users-list', '{"columns": [{"active": true, "accessor": "_select"}, {"active": true, "accessor": "id"}, {"active": true, "accessor": "name"}, {"active": true, "accessor": "email"}, {"active": true, "accessor": "roles"}, {"active": true, "accessor": "updatedAt"}, {"active": true, "accessor": "createdAt"}]}', '2024-04-20 15:40:16.739+00', '2024-04-20 15:40:16.739+00'),
(2, 'pages-list', '{"columns": [{"active": true, "accessor": "_select"}, {"active": true, "accessor": "title"}, {"active": true, "accessor": "layout"}, {"active": true, "accessor": "updatedAt"}, {"active": true, "accessor": "createdAt"}, {"accessor": "id"}, {"active": true, "accessor": "metaTitle"}, {"active": true, "accessor": "metaDescription"}, {"active": true, "accessor": "slug"}]}', '2024-04-20 15:41:27.449+00', '2024-04-20 15:41:27.449+00'),
(3, 'media-list', '{"columns": [{"active": true, "accessor": "_select"}, {"active": true, "accessor": "filename"}, {"active": true, "accessor": "updatedAt"}, {"active": true, "accessor": "createdAt"}, {"accessor": "id"}, {"accessor": "url"}, {"accessor": "thumbnailURL"}, {"accessor": "mimeType"}, {"accessor": "filesize"}, {"accessor": "width"}, {"accessor": "height"}, {"active": true, "accessor": "alt"}, {"active": true, "accessor": "caption"}]}', '2024-04-20 15:41:31.127+00', '2024-04-20 15:41:31.127+00'),
(4, 'categories-list', '{"columns": [{"active": true, "accessor": "_select"}, {"active": true, "accessor": "title"}, {"active": true, "accessor": "updatedAt"}, {"active": true, "accessor": "createdAt"}, {"active": true, "accessor": "id"}]}', '2024-04-20 15:48:57.158+00', '2024-04-20 15:48:57.158+00'),
(5, 'nav', '{"open": true}', '2024-04-20 15:49:02.498+00', '2024-04-20 15:49:02.498+00'),
(6, 'newsletter-list', '{"columns": [{"active": true, "accessor": "_select"}, {"active": true, "accessor": "id"}, {"active": true, "accessor": "updatedAt"}, {"active": true, "accessor": "title"}, {"active": false, "accessor": "layout"}, {"accessor": "createdAt"}, {"active": true, "accessor": "subject"}]}', '2024-04-21 12:38:14.466+00', '2024-04-21 12:38:14.466+00'),
(7, 'collapsed-Collections-groups', '[]', '2024-05-02 07:53:52.153+00', '2024-05-02 07:53:52.153+00');

INSERT INTO "public"."payload_preferences_rels" ("id", "order", "parent_id", "path", "users_id") VALUES
(6, NULL, 4, 'user', 1),
(8, NULL, 5, 'user', 1),
(14, NULL, 1, 'user', 1),
(45, NULL, 2, 'user', 1),
(46, NULL, 3, 'user', 1),
(49, NULL, 7, 'user', 1),
(50, NULL, 6, 'user', 1);

INSERT INTO "public"."users" ("id", "name", "updated_at", "created_at", "email", "reset_password_token", "reset_password_expiration", "salt", "hash", "login_attempts", "lock_until") VALUES
(1, 'Hurdi Gurdi', '2024-04-20 15:41:23.365+00', '2024-04-20 15:37:42.496+00', 'hurdi@gurdi.de', NULL, NULL, 'ac50df8f32d0006a5673a5c42112926c370bcf6ac7a99099b1f2ccd3caa78935', 'efbf6025546679f1ea35fb8a66beedb333654456c7201eabfba8422250ff21c106c285fc93e7c375b471d8de39125a679a96faf6ffe1ad19e1e1d0ffe3048490b59fb27a71d1068c2bb45a54e6c280559977b6aa14a1c5ae6524742dca4cc13fd4c76070dad7cd05230705df415c938fc9d823f800decb64d1fcb077990f4debf6c022e1e4f22cdae35a440bdd380b73d353cfc92854073b572ca21252df78844d18a37385f086e0ce1e4719f47259151b83617b5e8e7c96d19ac0a38f8f0ef959aeda6a187a02f9c7451a91e561ef93bedccead79c31c83ed022fc33b0c035840773a4909dc3b4558bf70e34e72b4189c2ab2bd283346d5d56945074bb72e43d27970216b7aae44f680c2d03ab00020fe722a238b54810872ed778e7982eee3c362b955febbff416ac48d772dd653c281134b66ef99a2cccc686fb81ed1d6ea96eda4883ffdb2abdab1ab64be642aab01e6025392798d119045395e65f111e61969308cfb05e5d914ec947d26d9396e2ca34192ddf6d086be83e8fe4e1b1a10d5ebf05bf2cab016622caa54e27b795bb9774a359e4436586210c961327897f916e2f2db6f69c34856c857b64482694ab1d0ff53280b9297b6ec9d0853f30f8b98b3fd37a986fdc071559afad756c091000ff7fa0f368155b88ca96d79b328817cc5222fc1e01027e932e2da935eb189cb0d51bdcc0bf0efc65f5eb44ce8cb1c', 0, NULL);

INSERT INTO "public"."users_roles" ("order", "parent_id", "value", "id") VALUES
(1, 1, 'admin', 9),
(2, 1, 'user', 10);



-- Indices
CREATE INDEX categories_created_at_idx ON public.categories USING btree (created_at);


-- Indices
CREATE INDEX media_created_at_idx ON public.media USING btree (created_at);
CREATE UNIQUE INDEX media_filename_idx ON public.media USING btree (filename);


-- Indices
CREATE INDEX newsletter_created_at_idx ON public.newsletter USING btree (created_at);
ALTER TABLE "public"."newsletter_blocks_quote" ADD FOREIGN KEY ("_parent_id") REFERENCES "public"."newsletter"("id") ON DELETE CASCADE;


-- Indices
CREATE INDEX newsletter_blocks_quote_order_idx ON public.newsletter_blocks_quote USING btree (_order);
CREATE INDEX newsletter_blocks_quote_parent_id_idx ON public.newsletter_blocks_quote USING btree (_parent_id);
CREATE INDEX newsletter_blocks_quote_path_idx ON public.newsletter_blocks_quote USING btree (_path);


-- Indices
CREATE INDEX pages_created_at_idx ON public.pages USING btree (created_at);
ALTER TABLE "public"."pages_blocks_quote" ADD FOREIGN KEY ("_parent_id") REFERENCES "public"."pages"("id") ON DELETE CASCADE;


-- Indices
CREATE INDEX pages_blocks_quote_order_idx ON public.pages_blocks_quote USING btree (_order);
CREATE INDEX pages_blocks_quote_parent_id_idx ON public.pages_blocks_quote USING btree (_parent_id);
CREATE INDEX pages_blocks_quote_path_idx ON public.pages_blocks_quote USING btree (_path);


-- Indices
CREATE INDEX payload_migrations_created_at_idx ON public.payload_migrations USING btree (created_at);


-- Indices
CREATE INDEX payload_preferences_key_idx ON public.payload_preferences USING btree (key);
CREATE INDEX payload_preferences_created_at_idx ON public.payload_preferences USING btree (created_at);
ALTER TABLE "public"."payload_preferences_rels" ADD FOREIGN KEY ("users_id") REFERENCES "public"."users"("id") ON DELETE CASCADE;
ALTER TABLE "public"."payload_preferences_rels" ADD FOREIGN KEY ("parent_id") REFERENCES "public"."payload_preferences"("id") ON DELETE CASCADE;


-- Indices
CREATE INDEX payload_preferences_rels_order_idx ON public.payload_preferences_rels USING btree ("order");
CREATE INDEX payload_preferences_rels_parent_idx ON public.payload_preferences_rels USING btree (parent_id);
CREATE INDEX payload_preferences_rels_path_idx ON public.payload_preferences_rels USING btree (path);


-- Indices
CREATE INDEX users_created_at_idx ON public.users USING btree (created_at);
CREATE UNIQUE INDEX users_email_idx ON public.users USING btree (email);
ALTER TABLE "public"."users_roles" ADD FOREIGN KEY ("parent_id") REFERENCES "public"."users"("id") ON DELETE CASCADE;


-- Indices
CREATE INDEX users_roles_order_idx ON public.users_roles USING btree ("order");
CREATE INDEX users_roles_parent_idx ON public.users_roles USING btree (parent_id);
